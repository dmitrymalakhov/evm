"use client";

import * as React from "react";

import { cn } from "@/lib/utils";

function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-md bg-gradient-to-r from-evm-steel/20 via-white/10 to-evm-steel/20",
        className,
      )}
      {...props}
    />
  );
}

export { Skeleton };


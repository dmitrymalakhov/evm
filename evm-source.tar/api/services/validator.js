import { eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { tickets, validatorCodes } from "../db/schema.js";
export function validateCode(inputCode) {
    const code = inputCode.trim().toUpperCase();
    const validator = db
        .select()
        .from(validatorCodes)
        .where(eq(validatorCodes.code, code))
        .get();
    if (validator) {
        return {
            status: validator.status,
            message: validator.message,
        };
    }
    const ticket = db
        .select()
        .from(tickets)
        .where(eq(tickets.qr, code))
        .get();
    if (ticket) {
        return {
            status: "valid",
            message: "Пропуск действителен. Приятной инициализации.",
        };
    }
    return {
        status: "invalid",
        message: "Код не распознан системой E.V.M.",
    };
}
